//********************************************************************************
// PANTHERID:  [6296562]
// CLASS: COP 2210 – [2021]
// ASSIGNMENT # [3]
// DATE: [2021-10-31]
//
// I hereby swear and affirm that this work is solely my own, and not the work 
// or the derivative of the work of someone else.
//********************************************************************************
package towerofterror;

import towerofterror.Floors;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class TowerOfTerror {

    
    public static void main(String[] args) {
        ImageIcon hauntedhouse = new ImageIcon("hauntedhouse.jpg");//Creates the icon for the Haunted House
        ImageIcon towerofterror = new ImageIcon("towerofterror.jpg");//Creates the icon for the Tower of Terror
        ImageIcon frontdoor = new ImageIcon("frontdoor.jpg");//Creates the icon for the Front door
               
         String userName = JOptionPane.showInputDialog("What is your name?");
//Asks the user for their name, and stores it as a variable
         JOptionPane.showMessageDialog(null, "Hello " + userName + "," + "\nWelcome to this year's Haunted.....!", "Haunted House?", 0, hauntedhouse);
         JOptionPane.showMessageDialog(null, "TOWER OF TERROR", "Tower of Terror", 0, towerofterror);
//Welcomes the player to the Haunted House
         JOptionPane.showMessageDialog(null, userName + "," + " a few rules before we begin:"
           + "\n     1. No Harming the Staff"
           + "\n     2. No Harming each other"
           + "\n     3. You need to collect two keys "
                 + "\n          in order to exit this tower"
           + "\n     4. Have fun and Good Luck", "Rules", 0, towerofterror);
//Explains the rules of the game to the player
       
        JOptionPane.showMessageDialog(null, userName + ", you are currently at the front door", "Front Door", 0, frontdoor);
//States the starting Position for the Player
        
        
        
        Floors floor = new Floors();
        floor.frontDoor();

















    }
    
}
